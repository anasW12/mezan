---
name: Modern Egyptian Enterprise Ledger
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#0051d5'
  on-tertiary: '#ffffff'
  tertiary-container: '#316bf3'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: IBM Plex Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 3rem
  display-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 1.875rem
    fontWeight: '600'
    lineHeight: 2.5rem
  headline-xl-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  title-md:
    fontFamily: IBM Plex Sans
    fontSize: 1rem
    fontWeight: '500'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
  metric-num:
    fontFamily: IBM Plex Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 1.75rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system serves a modern Egyptian enterprise audience navigating cloud-based financial accounting, tax compliance, invoicing, and real-time inventory management. The brand identity balances institutional trust and financial precision with the fluid ease of contemporary SaaS platforms. 

The aesthetic style merges **Corporate / Modern** structure with **Tactile Depth and Atmospheric Layers**. Rather than clinical, flat software or sterile white forms, the interface feels deeply grounded, stable, and visually calming during high-density financial data entry. 

Key attributes:
- **Direction & Locale:** Native Arabic right-to-left (`dir="rtl"`, `lang="ar"`) engineered from the core up, respecting reading mechanics and balance.
- **Atmosphere:** Deep emerald authority balanced against structural slate neutrals and subtle luminous gradients.
- **Tone:** Methodical, exact, transparent, and effortlessly agile.

## Colors

The color palette prioritizes visual hierarchy, financial legibility, and effortless status scanning. 

### Palette Architecture
- **Primary Emerald (`#059669`):** Represents fiscal health, liquidity, and operational growth. Primary buttons, key workflow confirmations, active state accents, and focused states leverage this anchor.
  - Hover: `#047857`
  - Soft Tint / Subtle Background: `#ecfdf5`
- **Secondary Slate Slate Core (`#0f172a`):** Conveys structural foundation and permanence. Used for primary typography, critical navigation chrome, and high-emphasis interface anchors.
  - Medium Support: `#475569` for body prose and descriptive subheads.
  - Muted Neutral: `#94a3b8` for placeholders, structural outlines, and inactive icons.
- **Tertiary Executive Blue (`#2563eb`):** Reserved for technical integrations, audit trails, and secondary action highlights.
- **Semantic Accents:**
  - **Revenue / Positive (`#10b981`):** Cash-in, completed audits, balanced accounts.
  - **Expense / Liability / Critical (`#f43f5e` / `#e11d48`):** Deficits, unpaid invoices, destructive system operations.
  - **Pending / Warning (`#f59e0b`):** Pending approvals, tax thresholds, low inventory counts.
  - **Informational (`#0ea5e9`):** System notices, reconciliation status chips.

### Background & Canvas Atmosphere
The canvas must never sit on a dead, flat white. It utilizes an atmospheric layered foundation: `#f8fafc` layered with soft radial emerald micro-mesh gradients (`rgba(5, 150, 105, 0.03)` to `rgba(15, 23, 42, 0.02)`) and an imperceptible micro-grid pattern to establish depth without distracting data entry.

## Typography

Typography centers on **IBM Plex Sans Arabic** (with fallback to Cairo and sans-serif). It offers architectural rigor, open counter-forms, and high legibility across dense Arabic ledger tables.

### Rules for Accounting Typography
- **Tabular Figures:** All numeric figures, monetary values (EGP / ج.م), quantities, and SKU tallies must enforce `font-feature-settings: "tnum" 1` to ensure strict vertical alignment across columns.
- **RTL Baseline Alignment:** Due to Arabic diacritics and character loops, Arabic text requires a 10–15% more generous line-height than equivalent Latin scripts to prevent character clipping.
- **Hierarchy Usage:**
  - `display-lg`: Dashboard financial summaries and ledger aggregate balances.
  - `headline-lg` / `headline-md`: Modular view headers, drawer titles, modal anchors.
  - `body-md`: Standard interactive table rows, ledger notes, descriptive text.
  - `metric-num`: Dedicated accounting metrics with invariant numeric tabular spacing.

## Layout & Spacing

The application operates on an enterprise **fluid grid** anchored by a structured frame designed specifically for Arabic RTL navigation.

### Shell Architecture
- **Right Sidebar (RTL Navigation):** Fixed width of `256px` anchored to the right edge (`right: 0`), holding system modules (Ledger, Invoices, Inventory, Warehouses, Reports, Settings).
- **Header:** Sticky `64px` height spanning the content area to the left of the sidebar, hosting global search, quick journal actions, tax notifications, and company profile switchers.
- **Main Canvas:** Dynamic fluid area (`calc(100vw - 256px)` on desktop) maintaining a structured 12-column sub-grid with `1.5rem` gutters and `2rem` margins.

### Responsive Breakpoints
- **Mobile (< 768px):** The right sidebar retreats into an off-canvas drawer controlled by a right-aligned hamburger toggle. Layout gutters compress to `0.75rem`, canvas margins to `1rem`. Table views convert into stacked structured cards.
- **Tablet (768px – 1024px):** The sidebar collapses to an icon-only right rail (`72px`). Tables enable horizontal scroll with sticky primary identifier columns.
- **Desktop (1025px+):** Full 256px sidebar, multi-panel ledger views, split screens for side-by-side reconciliation.

## Elevation & Depth

Visual hierarchy uses a refined combination of **tonal layers**, **delicate low-contrast borders**, and **ambient slate shadows**. 

### Elevation Tiers
- **Tier 0 (Canvas Surface):** Atmospheric `#f8fafc` layered with soft background glows. Flat, non-interactive.
- **Tier 1 (Cards & Data Tables):** Pure `#ffffff` surface, framed with a delicate border (`1px solid #f1f5f9`), lifted by an ultra-soft diffuse shadow: `0 4px 20px -2px rgba(15, 23, 42, 0.04)`.
- **Tier 2 (Popovers, Dropdowns, Date Pickers):** Pure `#ffffff` surface, border `1px solid #e2e8f0`, shadow `0 10px 25px -5px rgba(15, 23, 42, 0.08)`.
- **Tier 3 (Modals & Slide-out Drawers):** High-layer `#ffffff`, layered over a `rgba(15, 23, 42, 0.4)` backdrop blur overlay, with shadow `0 20px 30px -10px rgba(15, 23, 42, 0.12)`.

### Border Integrity
To maintain visual clarity among hundreds of data fields, avoid heavy borders. Use crisp hairpins (`#e2e8f0` or `#f1f5f9`) that define tabular cells and form boundaries without adding visual clutter.

## Shapes

The design system incorporates a **Rounded** shape language (`roundedness: 2`) that brings warmth to analytical enterprise software while preserving disciplined alignment.

### Geometry Specifications
- **Controls (40px Inputs, Buttons, Dropdowns):** `rounded-lg` (`0.5rem` / `8px`) provides compact tactile touchpoints suited for high-density accounting data entry.
- **Surfaces & Cards:** `rounded-xl` (`1rem` / `16px`) for sub-panels and ledger line groups; `rounded-2xl` (`1.25rem` / `20px`) for major analytical dashboard cards.
- **Pills & Badges:** `rounded-full` (`9999px`) exclusively reserved for numerical count badges, currency tags, and transaction status chips.

## Components

### Buttons
- **Height & Layout:** Standardized 40px height for primary workflows (`32px` for dense data table action triggers). Flex layout with `gap: 0.5rem`.
- **Primary:** Background `#059669`, text `#ffffff`, hover `#047857`. Focus ring `2px ring-emerald-500/20`.
- **Secondary / Outline:** Background `#ffffff`, border `1px solid #e2e8f0`, text `#0f172a`, hover background `#f8fafc`.
- **Destructive:** Background `#f43f5e`, text `#ffffff`, hover `#e11d48`.
- **RTL Icon Positioning:** Trailing action icons (e.g., arrow indicating forward submission) point leftwards (`rotate-180` if standard LTR glyphs are used). Leading icons sit on the right side of the text label.

### Input Fields & Selectors
- **Geometry:** Height 40px, `rounded-lg`, border `1px solid #cbd5e1`, background `#ffffff`, padding `0.5rem 0.875rem`.
- **Typography:** Arabic text aligned right (`text-right`). Tabular numbers for numerical inputs.
- **Focus State:** Border `#059669`, outline ring `3px rgba(5, 150, 105, 0.12)`.
- **Prefix / Suffix Currency Add-ons:** The Egyptian Pound symbol (`ج.م`) sits fixed as an integrated trailing block on the left end of the field (since typing numbers flows RTL).

### Chips & Status Badges
- **Dimensions:** Height 24px, padding `0.125rem 0.625rem`, `rounded-full`, typography `label-sm`.
- **Paid / Settled:** Background `#ecfdf5`, text `#047857`, border `1px solid rgba(16, 185, 129, 0.2)`.
- **Overdue / Deficit:** Background `#fff1f2`, text `#e11d48`, border `1px solid rgba(244, 63, 94, 0.2)`.
- **Draft / Pending:** Background `#fef3c7`, text `#b45309`, border `1px solid rgba(245, 158, 11, 0.2)`.

### Cards & Ledger Tables
- **Table Construction:** Clean alternating rows or crisp borders (`#f1f5f9`). Column headers use `label-md` in `#475569` with background `#f8fafc`. Header cells align right; monetary balance headers align right with numerical alignment flags.
- **Summary Cards:** Rounded-2xl white surfaces with primary metric displayed in `display-lg` tabular numerals, a secondary percentage badge, and an ambient emerald tint along the top border.

### Checkboxes & Radio Buttons
- **Checkboxes:** 18px × 18px, `rounded-md`, border `1.5px solid #cbd5e1`. Checked state: background `#059669`, border `#059669`, checkmark `#ffffff`.
- **Radio Buttons:** 18px × 18px, circular, with an emerald-600 inner pip on active selection.

### Right-Hand Navigation Item
- **Sidebar Elements:** 44px item height, `rounded-lg`, margin `0.25rem 0.75rem`.
- **Default:** Text `#475569`, icon `#94a3b8`, hover text `#0f172a`, hover background `#f1f5f9`.
- **Active State:** Background `#ecfdf5`, text `#059669`, icon `#059669`, bold typography (`fontWeight: 600`), accented with a 3px right-edge indicator bar (`#059669`).